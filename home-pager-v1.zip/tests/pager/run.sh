#!/bin/sh
# Jalankan dari folder tests/pager di dalam repo ren_phone (butuh g++).
set -e
PH=../../firmware/phone
sed -n '/HWS_PURE_BEGIN/,/HWS_PURE_END/p' $PH/hwscroll_renphone.ino > hws_pure.inc
sed -n '/HP_PURE_BEGIN/,/HP_PURE_END/p' $PH/pager_renphone.ino > pager_pure.inc
g++ -std=c++17 -O1 -Wall -o test_pager test_pager.cpp
./test_pager
