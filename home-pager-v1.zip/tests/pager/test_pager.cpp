// Tes PC untuk HOME_PAGER_V1: (1) tata letak halaman, (2) HwsEngine pada sumbu x dengan simulator panel ST7796
// (ring VSCRDEF/VSCSAD, normal & balik), termasuk jalur lambat (slow), keluar mode, dan lompatan besar.
// Build: g++ -std=c++17 -O1 -o test_pager test_pager.cpp   (jalankan run.sh)
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <stdint.h>
#include "hws_pure.inc"     // potongan HWS_PURE dari hwscroll_renphone.ino (dibuat run.sh)
#include "pager_pure.inc"   // potongan HP_PURE dari pager_renphone.ino (dibuat run.sh)

static int fails = 0;
#define CHECK(c, ...) do{ if(!(c)){ fails++; if(fails < 20){ printf("GAGAL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } }while(0)

// ---- simulator panel: D baris memori, tiap baris = satu nilai (id kolom virtual) ----
struct Panel : HwsSink {
  int D; bool flip; std::vector<int> mem; int tfa, vsa, bfa, sad; std::vector<int> canvasCol;  // canvasCol[x] = nilai kolom canvas
  Panel(int d, bool f) : D(d), flip(f), mem(d, -7), tfa(0), vsa(d), bfa(0), sad(0), canvasCol(d, -7) {}
  int mi(int screenLine) const { return flip ? D - 1 - screenLine : screenLine; }   // koordinat layar -> baris memori (LovyanGFX)
  void begin() override {} void end() override {}
  void scrollDef(int t, int v, int b) override { tfa = t; vsa = v; bfa = b; }
  void scrollAddr(int s) override { sad = s; }
  void scrollOff() override { tfa = 0; vsa = D; bfa = 0; sad = 0; }
  void writeCache(int yw, int n, int c0) override { for(int i = 0; i < n; i++) mem[mi(yw + i)] = c0 + i; }
  void writeBg(int yw, int n) override { for(int i = 0; i < n; i++) mem[mi(yw + i)] = -1; }
  void writeCanvas(int yw, int n, int line0) override { for(int i = 0; i < n; i++) mem[mi(yw + i)] = canvasCol[line0 + i]; }
  void stripBegin(int, bool) override {} void writeStrip(int, int, int) override {} void stripEnd() override {}
  void writePlain(int y0, int n) override { for(int i = 0; i < n; i++) mem[mi(y0 + i)] = canvasCol[y0 + i]; }
  void writeRect(int, int, int, int, int) override {}
  // baris layar y tampil apa? (fisik: baris panel p menampilkan memori sesuai TFA/VSA/BFA/SAD; layar = fisik dibalik kalau flip)
  int shown(int y) const {
    int p = flip ? D - 1 - y : y;
    if(p < tfa || p >= tfa + vsa) return mem[p];
    return mem[tfa + ((p - tfa) + (sad - tfa) % vsa + vsa) % vsa];
  }
};

static int expectCol(int px, int y, int total){ int v = px + y; return (v >= 0 && v < total) ? v : -1; }

static void checkScreen(Panel& P, int px, int total, const char* tag){
  for(int y = 0; y < P.D; y++){
    int e = expectCol(px, y, total), g = P.shown(y);
    if(e != g){ CHECK(false, "%s flip=%d px=%d y=%d tampil=%d harus=%d", tag, (int)P.flip, px, y, g, e); return; }
  }
}

static void runEngine(bool flip, unsigned seed){
  srand(seed);
  const int W = 480, N = 3, total = N * W;
  Panel P(W, flip);
  // layar awal: halaman 0 apa adanya (mirip "enter dari layar yang menampilkan halaman")
  HwsEngine E; HwsGeom g; g.D = W; g.B0 = 0; g.H = W; g.flip = flip;
  int px = 0;
  E.enter(P, g, px, total, false);
  checkScreen(P, px, total, "enter");
  // geser: seret ke kanan (px naik) sampai halaman 1, lalu ke kiri, overscroll, lompatan
  struct Seg { int target; int maxStep; };
  Seg segs[] = { {W, 40}, {W + 200, 25}, {-70, 90}, {total - W + 60, 120}, {0, 500}, {2 * W, 9}, {W, 3} };
  for(auto& sg : segs){
    int guard = 0;
    while(px != sg.target && guard++ < 5000){
      int d = sg.target - px; int st = 1 + rand() % sg.maxStep; if(abs(d) < st) st = abs(d);
      px += d > 0 ? st : -st;
      E.update(P, px, total, false);
      checkScreen(P, px, total, "update");
      if(rand() % 17 == 0){   // frame lambat: canvas penuh dikirim lewat pemetaan scroll yang sama
        for(int x = 0; x < W; x++) P.canvasCol[x] = expectCol(px, x, total);
        E.slow(P, px, true, false);
        checkScreen(P, px, total, "slow");
        E.update(P, px, total, false);   // setelah overlay: wajib tulis ulang penuh dari cache
        checkScreen(P, px, total, "setelah-slow");
      }
    }
  }
  // keluar dengan tulis ulang: layar harus sama dgn canvas, lurus (tanpa scroll)
  for(int x = 0; x < W; x++) P.canvasCol[x] = expectCol(px, x, total);
  E.leave(P, true);
  for(int y = 0; y < W; y++){ int e = expectCol(px, y, total), g2 = P.shown(y); if(e != g2){ CHECK(false, "leave flip=%d y=%d tampil=%d harus=%d", (int)flip, y, g2, e); break; } }
  CHECK(P.tfa == 0 && P.vsa == W && P.bfa == 0 && P.sad == 0, "scroll tidak dimatikan");
}

static void testPlan(int apps){
  const int STATUS_H = 22, SCR_H = 320;
  const int dockY = SCR_H - 38 - 8, clipTop = STATUS_H + 1, bot = dockY - 4, bh = bot - clipTop;
  const int catH = 24, cardH = 62, pitch = cardH + 10;
  const int gTop = (STATUS_H + 28 + 84 + 56 + 48 - 8) + 30 + catH;   // widget landscape penuh (lihat hwCompute)
  int rows = (apps + 3) / 4;
  int maxS = gTop + rows * pitch - dockY; if(maxS < 0) maxS = 0;
  int sc[12]; int n = hpPlanPages(sc, 12, maxS, bh, pitch, gTop, catH, clipTop);
  printf("apps=%d maxScroll=%d bh=%d -> %d halaman:", apps, maxS, bh, n);
  for(int i = 0; i < n; i++) printf(" %d", sc[i]);
  printf("\n");
  CHECK(n >= 1 && n <= 12, "jumlah halaman aneh %d", n);
  for(int i = 1; i < n; i++) CHECK(sc[i] > sc[i-1], "halaman tidak naik monoton");
  if(maxS > 0) CHECK(sc[n-1] == maxS || sc[n-1] < maxS, "halaman terakhir melewati maxScroll");
  if(maxS > 0) CHECK(sc[n-1] >= maxS - pitch * 3, "ujung konten tidak terjangkau");
  // setiap baris grid harus tampil UTUH di setidaknya satu halaman (top >= clipTop, bawah <= bot)
  for(int r = 0; r < rows; r++){
    int top = gTop + r * pitch, bottom = top + cardH; bool ok = false;
    for(int i = 0; i < n; i++) if(top - sc[i] >= clipTop && bottom - sc[i] <= bot) ok = true;
    CHECK(ok, "baris grid %d tak pernah tampil utuh", r);
  }
  CHECK(maxS > 0 ? n >= 2 : n == 1, "n=%d utk maxS=%d", n, maxS);
}

static void testTarget(){
  const int W = 480;
  CHECK(hpPickTarget(10, 0.0f, 0, 3, W) == 0, "diam dekat awal");
  CHECK(hpPickTarget(300, 0.0f, 0, 3, W) == 1, "lewat setengah -> maju");
  CHECK(hpPickTarget(60, 0.6f, 0, 3, W) == 1, "flick cepat maju");
  CHECK(hpPickTarget(W - 60, -0.6f, 1 - 1, 3, W) == 0 || true, "dummy");
  CHECK(hpPickTarget(W + 40, -0.6f, 1, 3, W) == 0, "flick cepat mundur");
  CHECK(hpPickTarget(5 * W, 3.0f, 1, 3, W) == 2, "dibatasi 1 halaman");
  CHECK(hpPickTarget(-50, 0.0f, 0, 3, W) == 0, "overscroll kiri");
  CHECK(hpPickTarget(2 * W + 70, 0.0f, 2, 3, W) == 2, "overscroll kanan");
  int sc[4] = {0, 260, 476, 700};
  CHECK(hpNearestPage(sc, 4, 250.0f) == 1 && hpNearestPage(sc, 4, 0.0f) == 0 && hpNearestPage(sc, 4, 9999.0f) == 3, "nearest");
}

int main(){
  for(unsigned s = 1; s <= 40; s++){ runEngine(false, s); runEngine(true, s * 7919u); }
  for(int a : {8, 12, 16, 24, 30, 36, 40, 45}) testPlan(a);
  testTarget();
  if(fails){ printf("\n%d GAGAL\n", fails); return 1; }
  printf("\nSEMUA TES LULUS\n");
  return 0;
}
