#!/usr/bin/env python3
"""apply_home_pager.py -- HOME_PAGER_V1: Home landscape berhalaman + hardware scroll horizontal ST7796.

Pakai (dari root repo ren_phone):   python3 apply_home_pager.py [--check]
Butuh pager_renphone.ino di folder yang sama dengan skrip ini. Idempoten (aman dijalankan ulang).
"""
import os, sys, shutil

ROOT = os.getcwd()
HERE = os.path.dirname(os.path.abspath(__file__))
PH = os.path.join(ROOT, "firmware", "phone")
CHECK = "--check" in sys.argv
errors = []

def read(p):
    with open(p, encoding="utf-8", newline="") as f: return f.read()
def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f: f.write(s)

def sub(s, old, new, what):
    n = s.count(old)
    if n != 1:
        errors.append("anchor '%s': ketemu %d kali (harus 1)" % (what, n))
        return s
    return s.replace(old, new)

phone_p = os.path.join(PH, "phone.ino")
hws_p = os.path.join(PH, "hwscroll_renphone.ino")
if not (os.path.exists(phone_p) and os.path.exists(hws_p)):
    sys.exit("Jalankan dari root repo ren_phone (firmware/phone/phone.ino tidak ditemukan).")

ph = read(phone_p)
if "HOME_PAGER_V1" in ph:
    sys.exit("HOME_PAGER_V1 sudah terpasang -- tidak ada yang diubah.")
hw = read(hws_p)

# ---------------- phone.ino ----------------
ph = sub(ph,
 "int hwsModeGet(); bool hwsModeSet(int); const char* hwsModeText(int);\n",
 "int hwsModeGet(); bool hwsModeSet(int); const char* hwsModeText(int);\n"
 "// HOME_PAGER_V1 (pager_renphone.ino): Home landscape berhalaman + hardware scroll horizontal\n"
 "bool hpOn(); bool hpIsActive(); bool hpMotionNow(); bool hpFrame(); bool hpPushHook(); bool hpBandRedirect();\n"
 "void hpTouchHeld(bool,int,int); void hpRelease(); void hpStep(float); void hpDrawDots(LGFX_Sprite&); void hpLoopGuard();\n"
 "void hpLeaveHook(const char*,int); int hpModeGet(); bool hpModeSet(int);\n",
 "prototipe")

ph = sub(ph,
 "if(!hwsPushHook()) rpPushCanvas();",
 "if(!hpPushHook() && !hwsPushHook()) rpPushCanvas();",
 "push()")

ph = sub(ph,
 "  hwsLoopGuard();   // HW_SCROLL_V1\n",
 "  hwsLoopGuard();   // HW_SCROLL_V1\n  hpLoopGuard();    // HOME_PAGER_V1\n",
 "loop guard")

ph = sub(ph,
 "else drawHome(canvas,homeScrollY); // v99:",
 "else { drawHome(canvas,homeScrollY); hpDrawDots(canvas); } // HOME_PAGER_V1: titik halaman. v99:",
 "renderCurrentFrame Home")

ph = sub(ph,
 "  if(hwsFrame()) return;   // HW_SCROLL_V1:",
 "  if(hpBandRedirect()) return;   // HOME_PAGER_V1: ring pager aktif -> frame penuh lewat push()\n  if(hwsFrame()) return;   // HW_SCROLL_V1:",
 "renderHomeBandFrame")

# sentuh: tahan/seret
ph = sub(ph,
 "    if(touched){\n      if(!wasTouched){\n        touchStartX=tx;touchStartY=ty;touchLastY=ty;\n        isSwiping=false;swipeStartTime=millis();\n        // v105: jari nangkep",
 "    if(touched && !searching && hpOn()){   // HOME_PAGER_V1: seret horizontal = geser halaman\n      hpTouchHeld(!wasTouched,tx,ty);\n    } else if(touched){\n      if(!wasTouched){\n        touchStartX=tx;touchStartY=ty;touchLastY=ty;\n        isSwiping=false;swipeStartTime=millis();\n        // v105: jari nangkep",
 "sentuh Home")

# lepas jari
ph = sub(ph,
 "      homePressedIdx=-1; // v-baru: jari lepas -> highlight tekan ilang apapun hasilnya\n      if(!searching){\n",
 "      homePressedIdx=-1; // v-baru: jari lepas -> highlight tekan ilang apapun hasilnya\n      if(!searching && hpOn()){ hpRelease(); }   // HOME_PAGER_V1: pegas ke halaman terdekat\n      else if(!searching){\n",
 "lepas jari")

# pegas
ph = sub(ph,
 "    } else if(!searching && homeScrollSpringing){\n",
 "    } else if(!searching && hpOn() && hpMotionNow()){   // HOME_PAGER_V1: pegas halaman\n      hpStep(dt);\n    } else if(!searching && homeScrollSpringing){\n",
 "pegas")

# dispatch render
ph = sub(ph,
 "    if(needRedraw){\n      // v106: PITA",
 "    if(needRedraw && hpFrame()){   // HOME_PAGER_V1: frame geser halaman (HW scroll / susun canvas)\n      needRedraw=false;\n    } else if(needRedraw){\n      // v106: PITA",
 "dispatch")

# baris Pengaturan: teks sesuai orientasi
ph = sub(ph,
 's.print(m==0?RPTR("Pakai cache"):(m==1?RPTR("Portrait saja"):RPTR("Portrait, balik")));',
 's.print(currentOrient==ORIENT_LANDSCAPE ? (m==0?RPTR("Landscape: vertikal"):(m==1?RPTR("Landscape: halaman"):RPTR("Landscape: balik"))) : (m==0?RPTR("Pakai cache"):(m==1?RPTR("Portrait saja"):RPTR("Portrait, balik")))); // HOME_PAGER_V1',
 "teks Pengaturan")

# ---------------- hwscroll_renphone.ino ----------------
hw = sub(hw, "int hwsModeGet(){\n", "int hwsModeGet(){\n  if(currentOrient == ORIENT_LANDSCAPE) return hpModeGet();   // HOME_PAGER_V1: mode landscape terpisah (NVS \"hwl\")\n", "hwsModeGet")
hw = sub(hw, "bool hwsModeSet(int v){\n", "bool hwsModeSet(int v){\n  if(currentOrient == ORIENT_LANDSCAPE) return hpModeSet(v);   // HOME_PAGER_V1\n", "hwsModeSet")
hw = sub(hw, "void hwsLeave(const char* why, int mode){\n", "void hwsLeave(const char* why, int mode){\n  hpLeaveHook(why, mode);   // HOME_PAGER_V1: semua titik keluar lama otomatis mencakup pager\n", "hwsLeave")

if errors:
    print("GAGAL -- tidak ada file yang ditulis:")
    for e in errors: print("  -", e)
    sys.exit(1)

src = os.path.join(HERE, "pager_renphone.ino")
if not os.path.exists(src): sys.exit("pager_renphone.ino tidak ada di sebelah skrip.")
if CHECK:
    print("OK (--check): semua anchor cocok, tidak ada yang ditulis."); sys.exit(0)

write(phone_p, ph); write(hws_p, hw)
shutil.copyfile(src, os.path.join(PH, "pager_renphone.ino"))
print("HOME_PAGER_V1 terpasang: phone.ino, hwscroll_renphone.ino diubah; pager_renphone.ino ditambah.")
print("Build -DRP_HOME_PAGER=0 untuk mematikan. Landscape: Pengaturan > Scroll Hardware (Mati/Auto/Balik).")
